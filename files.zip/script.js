// Add your JavaScript code here
console.log("Welcome to My Website!");